function f = ojfun_handle_lit(c,c_phi,s_phi,c_psi,s_psi,tp_full, D)
f = 0;
numPolar = size(D,1);
numPose  = size(D,2);
numPixel = size(D,3);

c_Hat = lsq_poly_crf_mix(c',linspace(0,1,20),5,1);

for j = 1:numPixel
t = tp_full((1+(j-1)*numPose):j*numPose);
M = reshape(D(:,:,j),numPolar,[]);

f = f + norm(2.*poly_mix(c_Hat, M) -...
            [ones(length(c_phi),1),c_phi,s_phi]...
            *([t.*ones(1,length(t)); (t).*ones(2,length(t))]...
            .*[ones(1,length(c_psi));c_psi;s_psi]), 2);
end
end