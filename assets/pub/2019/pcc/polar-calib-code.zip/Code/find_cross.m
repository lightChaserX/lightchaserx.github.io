function pixel = find_cross(line1, line2)
% y = alpha x + beta
pixel = zeros(2, 1);
pixel(1) = (line2(2)-line1(2)) / (line1(1) - line2(1));
pixel(2) = (line1(1)*line2(2)-line2(1)*line1(2)) / (line1(1) - line2(1));
end