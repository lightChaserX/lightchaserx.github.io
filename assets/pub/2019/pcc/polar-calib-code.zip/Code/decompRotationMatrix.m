function [rho, pitch, yaw] = decompRotationMatrix(varargin)
R = varargin{1};
if R(3, 1) ~= 1 || R(3, 1) ~= 1
    %rho(1) = -asin(R(3,1));
    pitch(1) = atan2(-R(3,1), sqrt(R(3,2)^2+R(3,3)^2));
    rho(1) = atan2(R(3, 2)/cos(pitch(1)), R(3, 3)/cos(pitch(1)));
    yaw(1) = atan2(R(2, 1)/cos(pitch(1)), R(1, 1)/cos(pitch(1)));
    if nargin > 1
        pitch(1) = pi - pitch(1);
        rho(1) = atan2(R(3, 2)/cos(pitch(1)), R(3, 3)/cos(pitch(1)));
        yaw(1) = atan2(R(2, 1)/cos(pitch(1)), R(1, 1)/cos(pitch(1)));
    end
else
    yaw = 0;
    if R(3, 1) == -1
        pitch = pi/2;
        rho = yaw + atan2(R(1, 2), R(1, 3));
    else
        pitch = -pi/2;
        rho = -yaw + atan2(-R(1, 2), -R(1, 3));
    end
end
end