function [cHat_refine,phi_refine,psi_refine,tp_refine] = BAfmincon_inverse(cHat_0,cHat,phi_hat,psi_hat,M_measured)
numPolar = length(phi_hat);
numPose = size(M_measured,1);
numPixel = size(M_measured,2);

tmpData = reshape(permute(M_measured,[3 1 2]), numPolar, []);
tmpDataNorm = (tmpData-min(tmpData(:)))/max(max(tmpData-min(tmpData(:))));
Mdata = reshape(tmpDataNorm,numPolar,numPose,numPixel);

numOrder = 6;

O_est = pinv([ones(length(phi_hat),1),cos(2*phi_hat'),sin(2*phi_hat')])...
        *(2.*poly_mix(cHat_0, tmpDataNorm));
tp = O_est(1,:); %% important

opt_func = @(x)ojfun_handle_inverse(x(1:numOrder),...
    reshape(x((numOrder+1):(numOrder+numPolar)),numPolar,1),...
    reshape(x((numOrder+1+numPolar):(numOrder+2*numPolar)),numPolar,1),...
    reshape(x((numOrder+1+2*numPolar):(numOrder+2*numPolar+numPose)),1,numPose),...
    reshape(x((numOrder+1+2*numPolar+numPose):(numOrder+2*numPolar+2*numPose)),1,numPose),...
    reshape(x((numOrder+1+2*numPolar+2*numPose):(numOrder+2*numPolar+numPose*(numPixel+2))),1,numPose*numPixel),...
    Mdata);

non_con = @(x)norm_noncon(x((numOrder+1):(numOrder+numPolar))', x((numOrder+1+numPolar):(numOrder+2*numPolar))',...
    x((numOrder+1+2*numPolar):(numOrder+2*numPolar+numPose))',x((numOrder+1+2*numPolar+numPose):(numOrder+2*numPolar+2*numPose))');

%Constraints
x0(1:numOrder,1) = flip(cHat(1:numOrder));
x0((numOrder+1):(numOrder+numPolar),1) = cos(2*phi_hat);
x0((numOrder+1+numPolar):(numOrder+2*numPolar),1) = sin(2*phi_hat);
x0((numOrder+1+2*numPolar):(numOrder+2*numPolar+numPose)) = cos(2*psi_hat);
x0((numOrder+1+2*numPolar+numPose):(numOrder+2*numPolar+2*numPose)) = sin(2*psi_hat);
x0((numOrder+1+2*numPolar+2*numPose):(numOrder+2*numPolar+numPose*(numPixel+2))) = tp';

Aeq = zeros(1,length(x0));
Aeq(1,1:numOrder) = 1;
beq(1) = 1;

%Monotonic Constraint as Positive first derivative
step = 0:0.01:1;
for i = 2:length(step)
    %monotonous constraint
    A1(i-1,1:numOrder) = -[step(i)-step(i-1),...
        step(i)^2-step(i-1)^2,...
        step(i)^3-step(i-1)^3,...
        step(i)^4-step(i-1)^4,...
        step(i)^5-step(i-1)^5,...
        step(i)^(1/2)-step(i-1)^(1/2)];
    b1(i-1,1) = 0;
    %convex constraint
end
step2 = linspace(0.0001, 1, length(step));
for i = 2:length(step2)
A2(i-1,1:numOrder) = -[0,...
        2*step2(i)^1-2*step2(i-1)^1,...
        3*step2(i)^2-3*step2(i-1)^2,...
        4*step2(i)^3-4*step2(i-1)^3,...
        5*step2(i)^4-5*step2(i-1)^4,...
        (1/2)*step2(i)^(-1/2)-(1/2)*step2(i)^(-1/2)];
    b2(i-1,1) = 0;
end
A1 = A1/max(abs(A1(:)));A1 = [A1 zeros(size(A1,1),length(x0)-numOrder)];
A2 = A2/max(abs(A2(:)));A2 = [A2 zeros(size(A2,1),length(x0)-numOrder)];

% diff_v = diff(poly_mix(cHat, 0:0.01:1),2);
% if abs(sum(diff_v)) < 1e-4
%     sig = 0;
% else
%     if length(diff_v(diff_v>0))/length(diff_v(diff_v<0))>1.5
%         sig = 1;
%     elseif length(diff_v(diff_v<0))/length(diff_v(diff_v>0))>1.5
%         sig = -1;
%     elseif length(diff_v(diff_v<0))/length(diff_v)>0.3 && length(diff_v(diff_v>0))/length(diff_v)>0.3
%         sig = 0;
%     end
% end

Aneq = [A1; 0*A2];
bneq = [b1; 0*b2];

% sig = sum(diff(polyval(cHat, 0:0.1:1),2))/abs(sum(diff(polyval(cHat, 0:0.1:1),2)));
% if abs(sum(diff(polyval(cHat, 0:0.1:1),2))) < 1e-6
%     Aneq = A1;
%     bneq = b1;
% else
%     Aneq = [A1; sig*A2];
%     bneq = [b1; sig*b2];
% end

lb = -inf*ones(1,length(x0)); 
ub = inf*ones(1,length(x0));
% lb(1:numOrder) = flip(cHat(1:numOrder))-0.0;
% ub(1:numOrder) = flip(cHat(1:numOrder))+0.0;
lb((numOrder+1):(numOrder+2*numPolar)) = -1.2;
ub((numOrder+1):(numOrder+2*numPolar)) = 1.2;
lb((numOrder+1+2*numPolar):(numOrder+2*numPolar+2*numPose)) = -1.2;
ub((numOrder+1+2*numPolar):(numOrder+2*numPolar+2*numPose)) = 1.2;
lb((numOrder+1+2*numPolar+2*numPose):(numOrder+2*numPolar+numPose*(numPixel+2))) = tp;
ub((numOrder+1+2*numPolar+2*numPose):(numOrder+2*numPolar+numPose*(numPixel+2))) = tp;

opts = optimset('Display','iter-detailed',...
                'Algorithm','sqp',...
                'MaxIter',300000,'MaxFunEvals',100000,...
                'FinDiffRelStep', 1e-6, 'PlotFcn', @optimplotfval);%,'PlotFcn',@optimplotstepsize);
[x_hat] = fmincon(opt_func,x0,Aneq,bneq,Aeq,beq,lb,ub,non_con,opts);

%% Deal with x
cHat_refine = [flip(x_hat(1:numOrder)); 0]';
c_phi_refine = x_hat((numOrder+1):(numOrder+numPolar));
s_phi_refine = x_hat((numOrder+1+numPolar):(numOrder+2*numPolar),1);
c_psi_refine = x_hat((numOrder+1+2*numPolar):(numOrder+2*numPolar+numPose));
s_psi_refine = x_hat((numOrder+1+2*numPolar+numPose):(numOrder+2*numPolar+2*numPose));

tp_refine = x_hat((numOrder+1+2*numPolar+2*numPose):(numOrder+2*numPolar+numPose*(numPixel+2)))';
phi_refine = atan2(s_phi_refine,c_phi_refine)/2/pi*180;
phi_refine = phi_refine-phi_refine(1);
phi_refine = mod(phi_refine,180);
phi_refine = phi_refine/180*pi;

psi_refine = atan2(s_psi_refine,c_psi_refine)/2;
end