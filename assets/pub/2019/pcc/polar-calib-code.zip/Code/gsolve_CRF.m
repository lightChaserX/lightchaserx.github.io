%% Gsolve
imagefiles = dir('*.pgm');
color_range = 2^8;
gsolve_Z = [];
time = [2:2:22];
im_time_box_show = [];
for i = 1:length(imagefiles)
    image_time = uint8(imread([imagefiles(i).name])/(2^8));
    imshow(image_time)
    im_time_box_show = [im_time_box_show, image_time(900:980, 700:850)];
    gsolve_Z = [gsolve_Z, round(mean2(image_time(900:980, 700:850)))];
end
figure(13), imshow(im_time_box_show)
gsolve_l = 10;
gsolve_B = zeros(size(gsolve_Z));
for i = 1:length(gsolve_Z(1,:))
    gsolve_B = log(time);
end

gsolve_w = zeros(1, color_range);
for i = 1:color_range
        if i <= (1 + color_range)/2
            gsolve_w(i) = i - 1;
        else
            gsolve_w(i) = color_range - i;
        end
end
[gsolve_g,gsolve_lE] = gsolve(gsolve_Z,gsolve_B,gsolve_l,gsolve_w)
figure(12), plot([0:255], exp(gsolve_g+gsolve_lE), 'b')
figure, plot(gsolve_Z, time, 'r-+'), %axis([0 30 0 256])