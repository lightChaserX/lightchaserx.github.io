function betaHat = lsf_plane(xx, yy, zz)
m = length(xx(:,1)); n = length(xx(1,:));
xx_bar = mean2(xx); yy_bar = mean2(yy); zz_bar = mean2(zz);
A = zeros(2, 2); b = zeros(2, 1);
for i = 1:m
    for j = 1:n
        A(1, 1) = A(1, 1) + (xx(i, j) - xx_bar)^2;
        A(1, 2) = A(1, 2) + (xx(i, j) - xx_bar)*(yy(i, j) - yy_bar);
        A(2, 1) = A(2, 1) + (xx(i, j) - xx_bar)*(yy(i, j) - yy_bar);
        A(2, 2) = A(2, 2) + (yy(i, j) - yy_bar)^2;
        b(1, 1) = b(1, 1) + (xx(i, j) - xx_bar)*(zz(i, j) - zz_bar);
        b(2, 1) = b(2, 1) + (yy(i, j) - yy_bar)*(zz(i, j) - zz_bar);
        betaHat = (A' * A) \ (A' * b);
        %betaHat = A \ b;
    end
end
normal_hat = [betaHat(1), betaHat(2), -1];

%% Plot results
figure, mesh(xx, yy, zz), hold on
for i = 1:m*n
quiver3(xx(i), yy(i), zz(i), 5*betaHat(1), 5*betaHat(2), -5);
quiver3(xx(i), yy(i), zz(i), -5*betaHat(1), -5*betaHat(2), +5)
end
%norm_c = cross([xx(6) - xx(3), yy(6) - yy(3), zz(6) - zz(3)], [xx(6) - xx(18), yy(6) - yy(18), zz(6) - zz(18)]);
%norm_c ./ norm_c(3)
end