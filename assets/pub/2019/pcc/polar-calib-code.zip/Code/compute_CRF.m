%close all, load('calib_data.mat'); 
% Do not need to load data, share the same feature points

irradiance = 0:12:204; num_im = 4;
irradiance = [irradiance 255];
gray_range = 2^8;
center_avr = zeros(num_im, length(irradiance));

for i = 1:num_im
im = imread(['Image' num2str(i) '.jpg']);

eval(['feature_points = x_' num2str(i) ';']);
figure(i)
imshow(im), hold on

height = 6; width = 8;
[center_avr_tmp, center_box_show] = select_points(height, width, im, feature_points);
center_avr(i, :) = center_avr_tmp;

figure(10), subplot(num_im, 1, i), imshow(center_box_show);

figure(11)
plot(center_avr_tmp/(gray_range-1), irradiance./(gray_range-1)), hold on
end

% cHat = lsq_poly_crf(center_avr, irradiance); % M w.r.t. I
% 
% figure(11)
% %plot(linspace(0, 1, 100), polyval([flip(cHat(2:end))' 1-sum(cHat(2:end)) cHat(1)], linspace(0, 1, 100)), 'b', 'LineWidth', 2)
% plot(linspace(0, 1, 100), polyval([flip(cHat(2:end))' cHat(1)], linspace(0, 1, 100)), 'b', 'LineWidth', 2)
% grid minor, axis([0 1 0 1]), xlabel('Measured Intensity'), ylabel('Irradiance')