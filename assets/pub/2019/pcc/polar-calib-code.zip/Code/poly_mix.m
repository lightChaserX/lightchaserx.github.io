function val = poly_mix(varargin)
cHat = varargin{1};
if nargin > 1
    data = varargin{2};
else
    data = linspace(0,1,100);
end
if nargin < 4
   numOrder1 = 5;
   numOrder2 = 1; 
else
   numOrder1 = varargin{3};
   numOrder2 = varargin{4};  
end
val = 0;
for i = 1:numOrder1
    val = val + cHat(i+numOrder2)*data.^(numOrder1-i+1);
end

for i = 1:numOrder2
    val = val + cHat(i)*data.^(1/(numOrder2-i+2));
end