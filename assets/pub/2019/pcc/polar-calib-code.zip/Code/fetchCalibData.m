prompt = 'Load the calib_data? [] default is no, other is yes >>';
load_data_flag = input(prompt);

if load_data_flag
    if exist('calib_data.mat', 'file')
        load('calib_data.mat');
    else
        prompt = 'click to obtain features? [] default is no, other is yes >>';
        click_flag = input(prompt);
        if click_flag
            data_calib, click_calib
        end
    end
    if ~exist('Calib_Results.mat', 'file')
        prompt = 'calib? [] default is no, other is yes >>';
        calib_flag = input(prompt);
        if calib_flag
            go_calib_optim, saving_calib
            prompt = 'Do you want to undistort all the calibration images (default is no, [])>>';
            undist_flag = input(prompt);
            if undist_flag
                undistort_image
            end
        end
    else
        load('Calib_Results.mat');
    end
end
