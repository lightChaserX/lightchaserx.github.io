function [cHat_refine,phi_refine,psi_refine,tp_refine] = BAfmincon(cHat,phi_hat,psi_hat,M_measured)
numPolar = length(phi_hat);
numPose = size(M_measured,1);
numPixel = size(M_measured,2);

%Mdata = zeros(numPolar, numPose);
% for j = 1:size(M_measured,1)
%     tmpData = reshape(M_measured(j,:,:),[11,37])';
%     Mdata(:,j) = mean(tmpData(polar_index,5:end),2);
% end
% Mdata = (Mdata-min(Mdata(:)))/max(max(Mdata-min(Mdata(:))));
tmpData = reshape(permute(M_measured,[3 1 2]), numPolar, []);
tmpDataNorm = (tmpData-min(tmpData(:)))/max(max(tmpData-min(tmpData(:))));
Mdata = reshape(tmpDataNorm,numPolar,numPose,numPixel);

O_est = pinv([ones(length(phi_hat),1),cos(2*phi_hat'),sin(2*phi_hat')])...
        *(2.*polyval(cHat, tmpDataNorm));
tp = O_est(1,:);

opt_func = @(x)ojfun_handle(x(1:5),...
    reshape(x(6:(5+numPolar)),numPolar,1),...
    reshape(x((6+numPolar):(5+numPolar+numPose)),1,numPose),...
    reshape(x((6+numPolar+numPose):(5+numPolar+numPose*(numPixel+1))),1,numPose*numPixel),...
    Mdata);

x0(1:5,1) = flip(cHat(1:5));
x0(6:(5+numPolar),1) = phi_hat;
x0((6+numPolar):(5+numPolar+numPose),1) = psi_hat;
%x0((6+numPolar+numPose):(5+numPolar+2*numPose),1) = tp';
x0((6+numPolar+numPose):(5+numPolar+numPose*(numPixel+1))) = tp';

Aeq = zeros(1,length(x0));
Aeq(1,1:5) = 1;
beq(1) = 1;

%Monotonic Constraint as Positive first derivative
step = 0:0.01:1;
for i = 2:length(step)
    %monotonous constraint
    A1(i-1,1:5) = -[step(i)-step(i-1),...
        step(i)^2-step(i-1)^2,...
        step(i)^3-step(i-1)^3,...
        step(i)^4-step(i-1)^4,...
        step(i)^5-step(i-1)^5];
    b1(i-1,1) = 0;
    %convex constraint
    A2(i-1,1:5) = -[0  2  6*step(i) 12*step(i)^2 20*step(i)^3];
    b2(i-1,1) = 0;
end
A1 = A1/max(abs(A1(:)));A1 = [A1 zeros(size(A1,1),length(x0)-5)];
A2 = A2/max(abs(A2(:)));A2 = [A2 zeros(size(A2,1),length(x0)-5)];
sig = sum(diff(polyval(cHat, 0:0.1:1),2))/abs(sum(diff(polyval(cHat, 0:0.1:1),2)));
if abs(sum(diff(polyval(cHat, 0:0.1:1),2))) < 1e-6
    Aneq = A1;
    bneq = b1;
else
    Aneq = [A1; sig*A2];
    bneq = [b1; sig*b2];
end

lb = -inf*ones(1,length(x0)); 
ub = inf*ones(1,length(x0));
% lb(1:5) = flip(cHat(1:5))'-0.01;
% ub(1:5) = flip(cHat(1:5))'+0.01;
lb((6+numPolar+numPose):(5+numPolar+numPose*(numPixel+1)))=0;
% lb((6+numPolar):(5+numPolar+numPose),1)=-pi;
% ub((6+numPolar):(5+numPolar+numPose),1)=pi;
opts = optimset('Display','iter',...
                'Algorithm','sqp',...
                'MaxIter',30000,'MaxFunEvals',10000,...
                'TolFun',.0001);
[x_hat] = fmincon(opt_func,x0,Aneq,bneq,Aeq,beq,lb,ub,[],opts);
cHat_refine = [flip(x_hat(1:5)); 0]';
phi_refine = x_hat(6:(5+numPolar));
psi_refine = x_hat((6+numPolar):(5+numPolar+numPose));
%tp_refine = x_hat((6+numPolar+numPose):(5+numPolar+2*numPose))';
tp_refine = x_hat((6+numPolar+numPose):(5+numPolar+numPose*(numPixel+1)))';
end