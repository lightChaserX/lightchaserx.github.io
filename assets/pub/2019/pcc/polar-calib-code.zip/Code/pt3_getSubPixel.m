function x=pt3_getSubPixel(x, y, I, map)
n_sq_x = 5;
n_sq_y = 5;
dX = 6;
dY = 6;
winty = 5;
wintx = 5;
% Compute the inside points through computation of the planar homography (collineation)

a00 = [x(1);y(1);1];
a10 = [x(2);y(2);1];
a11 = [x(3);y(3);1];
a01 = [x(4);y(4);1];

% Compute the planar collineation: (return the normalization matrix as well)

[Homo,Hnorm,inv_Hnorm] = compute_homography([a00 a10 a11 a01],[0 1 1 0;0 0 1 1;1 1 1 1]);


% Build the grid using the planar collineation:

x_l = ((0:n_sq_x)'*ones(1,n_sq_y+1))/n_sq_x;
y_l = (ones(n_sq_x+1,1)*(0:n_sq_y))/n_sq_y;
pts = [x_l(:) y_l(:) ones((n_sq_x+1)*(n_sq_y+1),1)]';

XX = Homo*pts;
XX = XX(1:2,:) ./ (ones(2,1)*XX(3,:));


% Complete size of the rectangle

W = n_sq_x*dX;
L = n_sq_y*dY;




Np = (n_sq_x+1)*(n_sq_y+1);

disp('Corner extraction...');

grid_pts = cornerfinder(XX,I,winty,wintx); %%% Finds the exact corners at every points!



%save all_corners x y grid_pts

grid_pts = grid_pts - 1; % subtract 1 to bring the origin to (0,0) instead of (1,1) in matlab (not necessary in C)



ind_corners = [1 n_sq_x+1 (n_sq_x+1)*n_sq_y+1 (n_sq_x+1)*(n_sq_y+1)]; % index of the 4 corners
ind_orig = (n_sq_x+1)*n_sq_y + 1;
xorig = grid_pts(1,ind_orig);
yorig = grid_pts(2,ind_orig);
dxpos = mean([grid_pts(:,ind_orig) grid_pts(:,ind_orig+1)]');
dypos = mean([grid_pts(:,ind_orig) grid_pts(:,ind_orig-n_sq_x-1)]');


x_box_kk = [grid_pts(1,:)-(wintx+.5);grid_pts(1,:)+(wintx+.5);grid_pts(1,:)+(wintx+.5);grid_pts(1,:)-(wintx+.5);grid_pts(1,:)-(wintx+.5)];
y_box_kk = [grid_pts(2,:)-(winty+.5);grid_pts(2,:)-(winty+.5);grid_pts(2,:)+(winty+.5);grid_pts(2,:)+(winty+.5);grid_pts(2,:)-(winty+.5)];


% figure(3);
% image(I); colormap(map); hold on;
% plot(grid_pts(1,:)+1,grid_pts(2,:)+1,'r+');
% plot(x_box_kk+1,y_box_kk+1,'-b');
% plot(grid_pts(1,ind_corners)+1,grid_pts(2,ind_corners)+1,'mo');
% %zoom on;
% drawnow;


Xi = reshape(([0:n_sq_x]*dX)'*ones(1,n_sq_y+1),Np,1)';
Yi = reshape(ones(n_sq_x+1,1)*[n_sq_y:-1:0]*dY,Np,1)';
Zi = zeros(1,Np);

Xgrid = [Xi;Yi;Zi];


% All the point coordinates (on the image, and in 3D) - for global optimization:

% figure(3);
% image(I); colormap(map); hold on;

x = zeros(n_sq_x+1, n_sq_y+1, 2); %h x w x
for m = 1:(n_sq_x+1)
    for n = 1:(n_sq_y+1)
        x(m, n, :) = grid_pts(:, (m-1)*(n_sq_y+1)+n);
        %         plot(x(m, n, 1)+1,x(m, n, 2)+1,'r+'); hold on, pause(0.1)
    end
end
end
%plot(x_box_kk+1,y_box_kk+1,'-b');
%plot(grid_pts(1,ind_corners)+1,grid_pts(2,ind_corners)+1,'mo');
%zoom on;
%drawnow;
%x = grid_pts;
%X = Xgrid;