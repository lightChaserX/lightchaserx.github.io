function f=ojfun_handle_inverse(c,c_phi,s_phi,c_psi,s_psi,tp_full,D)
%[rP, S] = revP([flip(c);0], [0, 1]);
f = 0;
numPolar = size(D,1);
numPose  = size(D,2);
numPixel = size(D,3);

for j = 1:numPixel
t = tp_full((1+(j-1)*numPose):j*numPose);
M = reshape(D(:,:,j),numPolar,[]);
yck = [ones(length(c_phi),1),c_phi,s_phi]*([t.*ones(1,length(t));(t).*ones(2,length(t))].*[ones(1,length(c_psi));c_psi;s_psi]);
f = f+norm(M-poly_mix(c,yck), 2);
end
f = f + .1*norm(c,2);
end