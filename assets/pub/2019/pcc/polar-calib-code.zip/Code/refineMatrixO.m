function [psi, ap, tp] = refineMatrixO(Mat)
m_size = size(Mat);
if m_size(1) == 3
    psi = atan2(Mat(3,:), Mat(2,:))/2;
    ap = abs(sqrt(Mat(3,:).^2 + Mat(2,:).^2));
    tp = Mat(1,:);
elseif m_size(1) == 2
    psi = atan2(Mat(2,:), Mat(1,:))/2;
    ap = 1; tp = 1;
end
%figure(66), plot(psi),hold on, plot(ap), plot(tp)
end