function [center_avr, center_box_show, whitecenter_box] = pattern3_sp(height, width, im, feature_points, map)
%% Points reshape
re_points = zeros(height, width, 2); %h x w x
for m = 1:height
    for n = 1:width
        re_points(m, n, :) = feature_points(:, (width-n)*height+m);
    end
end

center_pixel = center_extract(width, height, re_points);

%% White
whitecenter_box_joint = [];
k_win = 2;
for i = 2:2:length(center_pixel)
    j = floor(i/2);
    plot(center_pixel(1,i), center_pixel(2, i), '+'), hold on
    if length(size(im)) == 3
        whitecenter_box(:,:,j) = rgb2gray(im((center_pixel(2,i) - k_win):(center_pixel(2,i) + k_win),...
            (center_pixel(1, i)-k_win):(center_pixel(1,i) + k_win), :));
    else
        whitecenter_box(:,:,j) = im((center_pixel(2,i) - k_win):(center_pixel(2,i) + k_win),...
            (center_pixel(1, i)-k_win):(center_pixel(1,i) + k_win));
    end
end
whitecenter_avr = mean2(whitecenter_box);
whitecenter_box_show = mean(whitecenter_box(:, :, :), 3);

%% Greyscale
box_coord_map_9p16 = [10:15 1:3 16 17 4:6 18 19 7:9 20:25];
square_maps = ...
[1 2 3 6 5 4 7 8 9;
1 2 3 8 9 4 7 6 5;
1 6 7 2 5 8 3 4 9;
1 8 7 2 9 6 3 4 5;
3 2 1 4 5 6 9 8 7;
3 2 1 4 9 8 5 6 7;
7 6 1 8 5 2 9 4 3;
7 8 1 6 9 2 5 4 3;
3 4 9 2 5 8 1 6 7;
3 4 5 2 9 6 1 8 7;
7 8 9 6 5 4 1 2 3;
7 6 5 8 9 4 1 2 3;
9 8 7 4 5 6 3 2 1;
5 6 7 4 9 8 3 2 1;
9 4 3 8 5 2 7 6 1;
5 4 3 6 9 2 7 8 1;
3 2 9 4 1 8 5 6 7;
7 6 5 8 1 4 9 2 3];
black_center_show = [];
for i = 1:2:length(center_pixel)
    j = floor(i/2)+1;
    %plot(center_pixel(1,i), center_pixel(2, i), '+'), hold on,% pause(0.5)
    
    n = rem(i-1,7)+1;
    m = floor((i-1)/7)+1;
    subPixel=pt3_getSubPixel(...
        [re_points(m, n, 1) re_points(m, n+1, 1)...
         re_points(m+1, n+1, 1) re_points(m+1, n, 1)],...
        [re_points(m, n, 2) re_points(m, n+1, 2)...
         re_points(m+1, n+1, 2) re_points(m+1, n, 2)], im, map);
    for kr = 1:5
        for kc = 1:5
            kc_o = 2*kc - 1; kr_o = 2*kr - 1;
%             point_v(1, 1) = re_points(m, n, 1)+(re_points(m, n+1, 1)-re_points(m, n, 1)).*(kc_o./10);
%             point_v(1, 2) = re_points(m, n, 2)+(re_points(m, n+1, 2)-re_points(m, n, 2)).*(kc_o./10);
%             point_v(2, 1) = re_points(m+1, n, 1)+(re_points(m+1, n+1, 1)-re_points(m+1, n, 1)).*(kc_o./10);
%             point_v(2, 2) = re_points(m+1, n, 2)+(re_points(m+1, n+1, 2)-re_points(m+1, n, 2)).*(kc_o./10);
%             %
%             point_h(1, 1) = re_points(m, n, 1)+(re_points(m+1, n, 1)-re_points(m, n, 1)).*(kr_o./10);
%             point_h(1, 2) = re_points(m, n, 2)+(re_points(m+1, n+1, 2)-re_points(m, n, 2)).*(kr_o./10);
%             point_h(2, 1) = re_points(m, n+1, 1)+(re_points(m+1, n+1, 1)-re_points(m, n+1, 1)).*(kr_o./10);
%             point_h(2, 2) = re_points(m, n+1, 2)+(re_points(m+1, n+1, 2)-re_points(m, n+1, 2)).*(kr_o./10);
%             mid_pixel = find_cross(...
%                 pt3_lsf_line(point_v),...
%                 pt3_lsf_line(point_h));
%             plot(mid_pixel(1), mid_pixel(2), '+'), hold on
%             if length(size(im)) == 3
%                 center_box(:,:,(kr-1)*5+kc,j) = rgb2gray(im((mid_pixel(2) - k_win):(mid_pixel(2) + k_win),...
%                     (mid_pixel(1)-k_win):(mid_pixel(1) + k_win), :));
%             else
%                 center_box(:,:,(kr-1)*5+kc,j) = im((mid_pixel(2) - k_win):(mid_pixel(2) + k_win),...
%                     (mid_pixel(1)-k_win):(mid_pixel(1) + k_win));
%             end
            %plot(subPixel(kr, kc, 1)+1,subPixel(kr, kc, 2)+1,'r+'); hold on, pause(0.1)
            top = round(max(subPixel(kr, kc, 2), subPixel(kr, kc+1, 2)));
            bottom = round(min(subPixel(kr+1, kc, 2), subPixel(kr+1, kc+1, 2)));
            left = round(max(subPixel(kr, kc, 1), subPixel(kr+1, kc, 1)));
            right = round(min(subPixel(kr, kc+1, 1), subPixel(kr+1, kc+1, 1)));
            subCenter_y = round((left+right)/2);
            subCenter_x = round((top+bottom)/2);
%             plot(left,top,'r+'); hold on, pause(0.1)
%             plot(right,top,'r+'); hold on, pause(0.1)
%             plot(left,bottom,'r+'); hold on, pause(0.1)
%             plot(right,bottom,'r+'); hold on, pause(0.1)
            if length(size(im)) == 3
                center_box_full = rgb2gray(im((subCenter_x-k_win):(subCenter_x+k_win),...
                                                             (subCenter_y-k_win):(subCenter_y+k_win),:));
            else
                center_box_full = im((subCenter_x-k_win):(subCenter_x+k_win),...
                                     (subCenter_y-k_win):(subCenter_y+k_win));
            end
            center_box(:,:,(kr-1)*5+kc,j) = center_box_full; 
            num_rc = (kr-1)*5+kc;
            num_map = box_coord_map_9p16(num_rc);
            box_size = 2*k_win + 1;
            if num_map < 10 && num_map > 0
                num_map = square_maps(j, num_map);
                center_avr_mat(num_map, j) = mean2(center_box(:,:,(kr-1)*5+kc,j));
            else
                black_center_show = [black_center_show center_box(:,:,num_rc, j)];
            end
            center_box_show(((j-1)*box_size+1):j*box_size, ((num_map-1)*box_size+1):num_map*box_size)...
                = center_box(:,:,num_rc, j);
        end
    end
end

blackcenter_avr = mean2(black_center_show);
center_avr = mean(center_avr_mat, 2)';
center_avr = [blackcenter_avr center_avr whitecenter_avr];
%figure, imshow(whitecenter_box_show)
end