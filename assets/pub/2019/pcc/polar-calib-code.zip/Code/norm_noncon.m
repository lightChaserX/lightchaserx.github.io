function [cneq, ceq] = norm_noncon(c_phi,s_phi,c_psi,s_psi)
if length(c_phi)-length(c_psi) > 0
ceq = [c_phi.^2 + s_phi.^2 - 1;...
       c_psi.^2 + s_psi.^2 - 1 zeros(1,length(c_phi)-length(c_psi))];

elseif length(c_phi)-length(c_psi) < 0
    ceq = [c_phi.^2 + s_phi.^2 - 1 zeros(1,length(c_psi)-length(c_phi));...
       c_psi.^2 + s_psi.^2 - 1];
else
    ceq = [c_phi.^2 + s_phi.^2 - 1;...
       c_psi.^2 + s_psi.^2 - 1];
end
cneq = [];
% ceq = [];
% cneq = [abs(c_phi.^2+s_phi.^2-1)-1e-4;...
%        abs(c_psi.^2+s_psi.^2-1)-1e-4 zeros(1,length(c_phi)-length(c_psi))];
