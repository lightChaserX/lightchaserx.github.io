function center_pixel = center_extract(width, height, re_points)

%% Class Line
points_on_inv_line = cell(11, 1); %{[], [], [], [], [], [], [], [], [], [], []};
points_on_rev_line = cell(11, 1); %{[], [], [], [], [], [], [], [], [], [], []};
inv_line_index = zeros(height, width);
rev_line_index = zeros(height, width);
for m = 1:height
    for n = 1:width
        if ~(m == 1 && n == 1) && ~(m == height && n == width)
            inv_line_index(m, n) = m + n - 2;
            points_on_inv_line{m+n-2} = [points_on_inv_line{m+n-2} [m; n]];
        end
        if ~(m == 1 && n == width) && ~(m == height && n == 1)
            rev_line_index(m, n) = n-m+height-1;
            points_on_rev_line{n-m+height-1} = [points_on_rev_line{n-m+height-1} [m; n]];
        end
    end
end

%% Get Center Pixel
center_pixel = zeros(2, (width-1)*(height-1));
for m = 1:(height-1)
    for n = 1:(width-1)
        if inv_line_index(m, n+1) && rev_line_index(m, n)
            center_pixel(:, (m-1)*(width-1)+n) = find_cross(...
                lsf_line(re_points, points_on_rev_line{rev_line_index(m, n)}),...
                lsf_line(re_points, points_on_inv_line{inv_line_index(m, n+1)}));
        end
    end
end
center_pixel = round(center_pixel);
end