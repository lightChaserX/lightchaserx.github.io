phi0 = 0;
D_matrix = ones(numPolarAngle, numPixel);
phi = zeros(1,numPolarAngle);
D_mean_mat = zeros(numPose, numPolarAngle);
psi_mat = zeros(numPose, 2);
center_I = zeros(1, numPolarAngle);
for c = 1:numPose
    for t = 1:numPixel
        for k = 1:numPolarAngle
            center_I(k) = M_measured(c, t, k);
        end
        D_matrix(:, t) = 2*(center_I - min(center_I(:)))./max(center_I - min(center_I(:)));    
    end    
%     O_matrix = [ones(1,numPixel);...
%                 ones(1,numPixel)*cos(2*psi_vec(c));...
%                 ones(1,numPixel)*sin(2*psi_vec(c))];
%     P_matrix = D_matrix * ((O_matrix' * O_matrix) \ O_matrix');
%     
%     phi_hat = refineMatrixP(P_matrix);
    D_mean_mat(c, :) = mean(D_matrix,2) - 1;
    psi_mat(c,:) = [cos(2*(yaw(c)-2.2)), sin(2*(yaw(c)-2.2))];
end

phi_est_mat = ((psi_mat' * psi_mat) \ psi_mat' * D_mean_mat);
phi_est = atan2(phi_est_mat(2,:),phi_est_mat(1,:));
for ij = 1:length(phi_est)
    if phi_est(ij) < 0
        phi_est(ij) = 2*pi + phi_est(ij);
    end
end

for ij = 2:length(phi_est)
    if abs(phi_est(ij)-phi_est(ij-1)) > pi/2
        break;
    end
end

phi_est = phi_est./2;

%%%% elimit first < 0 case
for jk = 1:ij-1
    phi_est(jk) = phi_est(jk) - pi;
end

h_911 = figure(911),
set(h_911, 'Position', [100 500 450 400]);
plot([0:36]*5, phi_est/pi*180,...
     'ro', 'MarkerFaceColor', 'r',...
     'MarkerSize', 3),
hold on, plot([0:36]*5, [0:36]*5, 'b')
grid on, axis([0 180 0 180])
set(gca, 'XTick', 0:20:180);
set(gca, 'YTick', 0:20:180);