close all
fetchCalibData

% prompt = 'The number of images >>';
% num_im = input(prompt);
num_im = numel(dir('*.jpg'));
num_x_square = 6;
num_y_square = 8;
undistord_flag = [];

% irradiance = 0:12:204;
% irradiance = [irradiance 255];
irradiance = 255*[0:0.1:1];

normal_hat = zeros(num_im, 3);
theta = zeros(num_im, 1);
psi = zeros(num_im, 1);
center_avr = zeros(num_im, length(irradiance));

% prompt = 'squares in x? ([] default is 6)>>';
% num_x_square = input(prompt);
% if isempty(num_x_square)
%     num_x_square = 6;
% end

% prompt = 'squares in y? ([] default is 8)>>';
% num_y_square = input(prompt);
% if isempty(num_y_square)
%     num_y_square = 8;
% end

% prompt = 'Using undistord image ([] default is yes)>>';
% undistord_flag = input(prompt);

for kk = 1:num_im
    if isempty(undistord_flag)
        im = imread(['Image' num2str(kk) '.jpg']);
    elseif ~exist(['Image_rect' num2str(kk) '.bmp'], 'file')
        undistort_image
        im = imread(['Image_rect' num2str(kk) '.bmp']);
    else
        im = imread(['Image_rect' num2str(kk) '.bmp']);
    end
    
    figure(kk), title(['Image' num2str(kk)]), imshow(im), hold on
    if length(size(im)) == 3
        im = double(rgb2gray(im));
    else
        im = double(im);
    end
    
    if exist(['x_' num2str(kk)], 'var') & ...
            exist(['X_' num2str(kk)], 'var') & ...
            exist(['y_' num2str(kk)], 'var'),
        if isempty(undistord_flag)
            eval(['feature_points = x_' num2str(kk) '+1;']);
        else
            eval(['feature_points = y_' num2str(kk) '+1;']);
        end
        eval(['XX_kk = X_' num2str(kk) ';']);
        if ~isnan(XX_kk(1,1)) && exist(['omc_' num2str(kk)], 'var')
            eval(['omc_kk = omc_' num2str(kk) ';']);
            eval(['Tc_kk = Tc_' num2str(kk) ';']);
        end
        no_grid = 0;
        if ~exist(['n_sq_x_' num2str(kk)], 'var'),
            no_grid = 1;
        else
            eval(['n_sq_x = n_sq_x_' num2str(kk) ';']);
            if isnan(n_sq_x(1)),
                no_grid = 1;
            end;
        end;
        
        N_kk = size(XX_kk,2);
        if ~no_grid,
            eval(['n_sq_x = n_sq_x_' num2str(kk) ';']);
            eval(['n_sq_y = n_sq_y_' num2str(kk) ';']);
            if (N_kk ~= ((n_sq_x+1)*(n_sq_y+1))),
                no_grid = 1;
            end;
        end;
        
        if ~isnan(omc_kk(1,1)),
            R_kk = rodrigues(omc_kk);
            YY_kk = R_kk * XX_kk + Tc_kk * ones(1,length(XX_kk));
            
            if ~no_grid,
                YYx = zeros(n_sq_x+1,n_sq_y+1);
                YYy = zeros(n_sq_x+1,n_sq_y+1);
                YYz = zeros(n_sq_x+1,n_sq_y+1);
                
                YYx(:) = YY_kk(1,:);
                YYy(:) = YY_kk(2,:);
                YYz(:) = YY_kk(3,:);
            end
        end
    end
    
    [center_avr_tmp, center_box_show, whitecenter_box] = pattern3_sp(num_x_square,...
        num_y_square,...
        im,...
        feature_points,...
        map);
    center_avr(kk, :) = center_avr_tmp;
%     for kctt = 1:17
%         wc_boxmean(k, kctt, kk) = mean2(whitecenter_box(:,:,kctt));
%     end
    %figure(200), plot(wc_boxmean), hold on
    %figure(10), subplot(num_im, 1, kk), imshow(center_box_show);
    figure(30+kk), imshow(uint8(center_box_show));
    [normal_hat(kk, :), theta(kk), psi(kk)] = lsf_normal(YYx, YYy, YYz);
end

cHat = lsq_poly_crf(center_avr, irradiance); % (M, I)

h_11 = figure(11);
set(h_11, 'Position', [100 500 450 400]);
plot(linspace(0, 1, 100),...
    polyval(cHat, linspace(0, 1, 100)),...
    'r', 'LineWidth', 2)
grid on, axis([0 1 0 1])
hold on
plot(linspace(0, 1, 100),...
    polyval([1 0], linspace(0, 1, 100)),...
    'k--', 'LineWidth', 1)
set(gca, 'XTick', 0:0.1:1);
set(gca, 'YTick', 0:0.1:1);
xlabel('Normalized observation');
ylabel('Normalized irradiance');
