clear dorf_cHat
color_str = 'rgbcm';
for numOrder = 5:9
    for i = 1:size(dorfM, 1)
        poly_c = lsq_poly_crf(dorfM(i,:), dorfI(i,:),numOrder)';
        %dorf_cHat(i,j,:) = poly_c;
        crf_diff = polyval(poly_c, dorfM(i,:)) - dorfI(i,:);
        dorf_RMSE(i,numOrder-4) = sqrt(mean((crf_diff).^2));
        dorf_Disparity(i,numOrder-4) = max(abs(crf_diff));
        %figure(1), plot(dorfM(i,:), dorfI(i,:)), pause
    end
    
    figure(4), plot(dorf_RMSE(:,numOrder-4), color_str(rem(numOrder,5)+1), 'LineWidth', 1), hold on,
    figure(5), plot(dorf_Disparity(:,numOrder-4), color_str(rem(numOrder,5)+1), 'LineWidth', 1), hold on
end