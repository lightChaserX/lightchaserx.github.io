function reNameImage(varargin)
if nargin < 1
    dir_files = '.'; % directory path
    img_predix = 'Image';
elseif nargin == 1
    dir_files = varargin{1};
elseif nargin == 2
    dir_files = varargin{1};
    img_predix = varargin{2};
end

if ~exist(fullfile(dir_files,'jpgfiles'), 'dir')
    mkdir('jpgfiles')
end
if ~exist(fullfile(dir_files,'tiffiles'), 'dir')
    mkdir('tiffiles')
end
    
S = dir(fullfile(dir_files,'*.tif')); % get list of files in directory
N = natsortfiles({S.name}); % sort file names into order
for k = 1:numel(N)
    fprintf([fullfile(dir_files,N{k}) '\n'])
    img = imread(N{k});
    if isa(img, 'uint16')
        scale = 2^8;
    elseif isa(img, 'uint8')
        scale = 1;
    end
    imwrite(uint8(img/scale), ['jpgfiles/' img_predix num2str(k) '.jpg']);
    movefile(N{k}, 'tiffiles')
end
end

% function reNameImage(varargin)
% if nargin < 1
%     dir_files = '.'; % directory path
%     img_predix = 'Image';
% elseif nargin == 1
%     dir_files = varargin{1};
%     img_predix = 'Image';
% elseif nargin == 2
%     dir_files = varargin{1};
%     img_predix = varargin{2};
% end
% 
% if ~exist(fullfile(dir_files,'jpgfiles'), 'dir')
%     mkdir('jpgfiles')
% end
% if ~exist(fullfile(dir_files,'tiffiles'), 'dir')
%     mkdir('tiffiles')
% end
%     
% S = dir(fullfile(dir_files,'*.tif')); % get list of files in directory
% N = natsortfiles({S.name}); % sort file names into order
% for k = 1:numel(N)
%     fprintf([fullfile(dir_files,N{k}) '\n'])
%     img = imread(fullfile(dir_files,N{k}));
%     if isa(img, 'uint16')
%         scale = 2^8;
%     elseif isa(img, 'uint8')
%         scale = 1;
%     end
%     imwrite(uint8(img/scale), ['jpgfiles/' dir_files '/' img_predix num2str(k) '.jpg']);
%     %movefile(N{k}, 'tiffiles')
% end
% end