function [ phi ] = initGuess_GivenOD_Final( varargin )
%% Initial guess of phi given M and O
%  M   - unnormalized measured intensity
%        size is numPose x numPixel x numPolarAngle
%  psi - the phase angle/yaw-constant
M = varargin{1};
psi = varargin{2};
cHat = varargin{3};
if nargin > 3
    phi_true = varargin{4};
end

color_str      = 'rgbmky';
numPose        = length(M(:,1,1));
numPixel       = length(M(1,:,1));
numPolarAngle  = length(M(1,1,:));
tilde_D_matrix = zeros();
tilde_P_matrix = zeros();

M_norm     = (M - min(M(:)))./max(max(max(M - min(M(:)))));
I_hat      = polyval(cHat, M_norm); 
I_hat_disp = reshape(I_hat,[],numPolarAngle)';
% for i = 1:numPose
%     figure(5), 
%         plot(phi_true/pi*180, I_hat_disp(:, i:numPose:end),...
%             [color_str(i) '-']),
%         hold on
% end
% title('Intensity data to estimate \psi')

%construct in a balanced way
[row col] = size(I_hat_disp); 
MatrixPhase = [repmat(cos(2*psi),1,11); repmat(sin(2*psi),1,11)]/row;
SumIdata = sum(I_hat_disp,1); 
MeanIdata = mean(I_hat_disp,1);
Mat = zeros(row*col,2*row);
for index = 1:col
    Mat(row*(index-1)+1:row*index,1:2:end) = I_hat_disp(:,index)*MatrixPhase(1,index)*ones(1,row); 
    Mat(row*(index-1)+1:row*index,2:2:end) = I_hat_disp(:,index)*MatrixPhase(2,index)*ones(1,row);
    Mat(row*(index-1)+1:row*index,1:2:end) = Mat(row*(index-1)+1:row*index,1:2:end) - ...
        (SumIdata(index)*MatrixPhase(1,index))*eye(row,row);
    Mat(row*(index-1)+1:row*index,2:2:end) = Mat(row*(index-1)+1:row*index,2:2:end) - ...
        (SumIdata(index)*MatrixPhase(2,index))*eye(row,row);
end

Vec = -I_hat_disp + repmat(MeanIdata,size(I_hat_disp,1),1);
Vec = Vec(:);

O_matrix = pinv(Mat)*Vec;

%alternate
[row col] = size(I_hat_disp); 
MatrixPhase = [ones(1,col); repmat(cos(2*psi),1,numPixel); repmat(sin(2*psi),1,numPixel)];

MatP = reshape(O_matrix,2,row).'; 
MatP = MatP./repmat(sqrt(sum(MatP.^2,2)),1,2); 
MatP = [ones(row,1) MatP];

for itr = 1:200
    TempMat = MatP*MatrixPhase;
    %calculate MatO
    for i = 1:col
        scale = sum(I_hat_disp(:,i).*TempMat(:,i))/sum(TempMat(:,i).^2);
        MatO(:,i) = scale*MatrixPhase(:,i);
    end
    
    %calculate MatP
    A = MatO(2:3,:)*MatO (2:3,:).'; 
    for i = 1:row
        % call quadratic eigenvalue solver
        b = MatO(2:3,:)*(I_hat_disp(i,:)-MatO(1,:)).';
        [eigVec eigVal] = polyeig(A.'*A-b*b.', -2*A, eye(2));
        eigVal = real(eigVal(find(abs(imag(eigVal))<1e-4)));
        
        temp = ((A-min(eigVal)*eye(2))\b).';
        
        MatP(i,:) = [1 temp/norm(temp)];
    end
    
    obj(itr) = norm(I_hat_disp - MatP*MatO);
    
end

O_matrix = MatP(:,2:3).'; 
O_matrix = O_matrix(:);
obj(end);
% figure(9); plot(obj,'r*');

O_mat = reshape(O_matrix, 2,[]);
phi = atan2(O_mat(2,:),O_mat(1,:))/2;
phi = mod(phi/pi*180,180);

phi = phi/180*pi;
end