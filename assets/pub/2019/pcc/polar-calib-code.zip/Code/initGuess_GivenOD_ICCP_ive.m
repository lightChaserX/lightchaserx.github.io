function [ phi ] = initGuess_GivenOD_ICCP_ive( varargin )
%% Initial guess of phi given M and O
%  M   - unnormalized measured intensity
%        size is numPose x numPixel x numPolarAngle
%  psi - the phase angle/yaw-constant
M = varargin{1};
psi = varargin{2};
cHat = varargin{3};
if nargin > 3
    phi_true = varargin{4};
end

color_str      = 'rgbmky';
numPose        = length(M(:,1,1));
numPixel       = length(M(1,:,1));
numPolarAngle  = length(M(1,1,:));
tilde_D_matrix = zeros();
tilde_P_matrix = zeros();

M_norm     = (M - min(M(:)))./max(max(max(M - min(M(:)))));
I_hat      = polyval(cHat, M_norm); 
I_hat_disp = reshape(I_hat,[],numPolarAngle)';
% for i = 1:numPose
%     figure(5), 
%         plot(phi_true/pi*180, I_hat_disp(:, i:numPose:end),...
%             [color_str(i) '-']),
%         hold on
% end
% title('Intensity data to estimate \psi')

%random initialization
[row col] = size(I_hat_disp); 
O_matrix = rand(row,2); 

%good initialization
%  Angle = 5:5:175; Angle = Angle*2/180*pi; 
%  O_matrix = [cos(Angle.') sin(Angle.')];

O_matrix = O_matrix./repmat(sqrt(sum(O_matrix.^2,2)),1,2); 
MatrixP = [ones(row,1) O_matrix]; 
MatrixP(1,2:3) = [1,0];

maxItr = 100;
for i = 1:maxItr
%alternate
MatrixO = pinv(MatrixP)*I_hat_disp;
%MatrixO(MatrixO<0) = 0; 

%calculate MatrixP
temp = (I_hat_disp(2:end,:)-ones(row-1,1)*MatrixO(1,:))*pinv(MatrixO(2:3,:));
temp = temp./repmat(sqrt(sum(temp.^2,2)),1,2);

MatrixP = [ones(row-1,1) temp];
MatrixP = [[1 1 0]; MatrixP];

obj(i) = norm(I_hat_disp-MatrixP*MatrixO);
end

if sum(MatrixO(3,:)) > 0
    MatrixO(3,:) = -MatrixO(3,:); 
    MatrixP(:,3) = -MatrixP(:,3);
end

O_matrix = MatrixP(:,2:3).'; 
O_matrix = O_matrix(:);
obj(end);
% figure; plot(obj,'r*');

O_mat = reshape(O_matrix, 2,[]);
phi = atan2(O_mat(2,:),O_mat(1,:))/2;
phi = pi/2 - phi;
phi = phi-phi(1);
phi = mod(phi/pi*180,180);

% h_911 = figure(2);
% set(h_911, 'Position', [100 500 450 400]);
% plot(phi_true/pi*180, phi,...
%     'd', 'Color', 'm',...
%     'MarkerFaceColor', 'm',...
%     'MarkerSize', 3),
% hold on,
% grid on, axis([0 180 0 180])
% set(gca, 'XTick', 0:20:180);
% set(gca, 'YTick', 0:20:180);

phi = phi/180*pi;
end