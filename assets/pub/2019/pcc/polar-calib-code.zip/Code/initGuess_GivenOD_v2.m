function [ phi ] = initGuess_GivenOD_v2( varargin )
%% Initial guess of phi given M and O
%  M   - unnormalized measured intensity
%        size is numPose x numPixel x numPolarAngle
%  psi - the phase angle/yaw-constant
M = varargin{1};
psi = varargin{2};
cHat = varargin{3};
if nargin > 3
    phi_true = varargin{4};
end

color_str      = 'rgbmky';
numPose        = length(M(:,1,1));
numPixel       = length(M(1,:,1));
numPolarAngle  = length(M(1,1,:));
tilde_D_matrix = zeros();
tilde_P_matrix = zeros();

M_norm     = (M - min(M(:)))./max(max(max(M - min(M(:)))));
I_hat      = polyval(cHat, M_norm); 
I_hat_disp = reshape(I_hat,[],numPolarAngle)';
% for i = 1:numPose
%     figure(5), 
%         plot(phi_true/pi*180, I_hat_disp(:, i:numPose:end),...
%             [color_str(i) '-']),
%         hold on
% end
% title('Intensity data to estimate \psi')

Pixel_index = 10:11;
numNewPixel = length(Pixel_index);
for k = 2:numPolarAngle
    for t = 1:numNewPixel
        for c = 1:numPose
            id = (k-2)*numNewPixel*numPose+(t-1)*numPose+c;
            tilde_D_matrix(id, 1) = I_hat(c,Pixel_index(t),1)-...
                I_hat(c,Pixel_index(t),k);
            
            tilde_P_matrix(id, 1) = I_hat(c,Pixel_index(t),k)*cos(2*psi(c));
            tilde_P_matrix(id, 2) = I_hat(c,Pixel_index(t),k)*sin(2*psi(c));
            tilde_P_matrix(id, 1+2*(k-1)) = -I_hat(c,Pixel_index(t),1)*cos(2*psi(c));
            tilde_P_matrix(id, 2*k) = -I_hat(c,Pixel_index(t),1)*sin(2*psi(c));
        end
    end
end
O_matrix = pinv(tilde_P_matrix)*tilde_D_matrix;
O_mat = reshape(O_matrix, 2,[]);
phi = atan2(O_mat(2,:),O_mat(1,:))/2;
phi = mod(phi/pi*180,180);

% h_911 = figure(2);
% set(h_911, 'Position', [100 500 400 400]);
% % plot(phi_true/pi*180, phi,...
% %     'o', 'Color', 'g',...
% %     'MarkerFaceColor', 'g',...
% %     'MarkerSize', 3),
% hold on,
% grid on, axis([0 180 0 180])
% set(gca, 'XTick', 0:20:180);
% set(gca, 'YTick', 0:20:180);

phi = phi/180*pi;
end