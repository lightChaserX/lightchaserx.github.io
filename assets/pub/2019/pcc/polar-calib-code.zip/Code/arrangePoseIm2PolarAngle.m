function arrangePoseIm2PolarAngle(prefix, numPose, numPolarAngle)
%% Fetch from P to Rotate
% In the parrent dir run it
if nargin < 2
    prompt = 'Input the number of pose';
    numPose = input(prompt);
    prompt = 'Input the number of polarizer angle';
    numPolarAngle = input(prompt);
end

for i=1:numPolarAngle
    for j = 1:numPose
        ft_im_name = [prefix num2str(j) '/jpgfiles/Image' num2str(i) '.jpg'];
        if ~exist(['R' num2str(i)], 'dir')
            mkdir(['R' num2str(i)])
        end
        imwrite(imread(ft_im_name), ['R' num2str(i) '/Image' num2str(j) '.jpg']);
        %delete(ft_im_name)
    end
end
end