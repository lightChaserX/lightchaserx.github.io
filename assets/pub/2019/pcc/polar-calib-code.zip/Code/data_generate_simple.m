function M=data_generate_simple(varargin)
if nargin < 1
    phi = (0:5:180)/180*pi;
    psi = [-0.7277   -0.8879   -0.4533   -0.4412   -0.5514];
    c_coeff = [0 0 0 0 1 0];
    I_max = 0:0.1:1;
elseif nargin == 1
    phi = (0:5:180)/180*pi;
    psi = [-0.7277   -0.8879   -0.4533   -0.4412   -0.5514];
    c_coeff = [0 0 0 0 1 0];
    I_max = varargin{1};
elseif nargin >= 4
    phi = varargin{1};
    psi = varargin{2};
    c_coeff = varargin{3};
    I_max = varargin{4};
end

I_min = zeros(size(I_max));
tp = (I_max+I_min)/2;
ap = (I_max-I_min)/2;

numPose = length(psi);
numPolar = length(phi);
numPixel = length(tp);

I = zeros(numPose,numPixel,numPolar);

for i = 1:numPose
    for j = 1:numPolar
        for k = 1:numPixel
            I(i, k, j) = tp(k) + ap(k)*cos(2*(phi(j) - psi(i)));
        end
    end
end
M = polyval(c_coeff, I)*255;
end