function f = ojfun_handle(c, phi, psi, tp_full, D)
phi = mod(phi/pi*180,180)/180*pi;
f = 0;
for j = 1:size(D,3)
t = tp_full((1+(j-1)*size(D,2)):j*size(D,2));
M = reshape(D(:,:,j),size(D,1),[]);
f = f + norm(2.*polyval([flip(c); 0], M) -...
            [ones(length(phi),1),cos(2*phi),sin(2*phi)]...
            *([t.*ones(1,length(t)); (t).*ones(2,length(t))]...
            .*[ones(1,length(psi));cos(2*psi);sin(2*psi)]), 2);
end
end