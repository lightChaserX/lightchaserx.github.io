function [cHat_refine,phi_refine,psi_refine,tp_refine] = BAfmincon_v2(cHat,phi_hat,psi_hat,M_measured)
numPolar = length(phi_hat);
numPose = size(M_measured,1);
numPixel = size(M_measured,2);

tmpData = reshape(permute(M_measured,[3 1 2]), numPolar, []);
tmpDataNorm = (tmpData-min(tmpData(:)))/max(max(tmpData-min(tmpData(:))));
Mdata = reshape(tmpDataNorm,numPolar,numPose,numPixel);

O_est = pinv([ones(length(phi_hat),1),cos(2*phi_hat'),sin(2*phi_hat')])...
        *(2.*polyval(cHat, tmpDataNorm));
tp = O_est(1,:);

opt_func = @(x)ojfun_handle_v2(x(1:5),...
    reshape(x(6:(5+numPolar)),numPolar,1),...
    reshape(x((6+numPolar):(5+2*numPolar)),numPolar,1),...
    reshape(x((6+2*numPolar):(5+2*numPolar+numPose)),1,numPose),...
    reshape(x((6+2*numPolar+numPose):(5+2*numPolar+2*numPose)),1,numPose),...
    reshape(x((6+2*numPolar+2*numPose):(5+2*numPolar+numPose*(numPixel+2))),1,numPose*numPixel),...
    Mdata);

non_con = @(x)norm_noncon(x(6:(5+numPolar))', x((6+numPolar):(5+2*numPolar))',...
    x((6+2*numPolar):(5+2*numPolar+numPose))',x((6+2*numPolar+numPose):(5+2*numPolar+2*numPose))');

%Constraints
x0(1:5,1) = flip(cHat(1:5));
x0(6:(5+numPolar),1) = cos(2*phi_hat);
x0((6+numPolar):(5+2*numPolar),1) = sin(2*phi_hat);
x0((6+2*numPolar):(5+2*numPolar+numPose)) = cos(2*psi_hat);
x0((6+2*numPolar+numPose):(5+2*numPolar+2*numPose)) = sin(2*psi_hat);
x0((6+2*numPolar+2*numPose):(5+2*numPolar+numPose*(numPixel+2))) = tp';

Aeq = zeros(1,length(x0));
Aeq(1,1:5) = 1;
beq(1) = 1;

%Monotonic Constraint as Positive first derivative
step = 0:0.01:1;
for i = 2:length(step)
    %monotonous constraint
    A1(i-1,1:5) = -[step(i)-step(i-1),...
        step(i)^2-step(i-1)^2,...
        step(i)^3-step(i-1)^3,...
        step(i)^4-step(i-1)^4,...
        step(i)^5-step(i-1)^5];
    b1(i-1,1) = 0;
    %convex constraint
    A2(i-1,1:5) = -[0  2  6*step(i) 12*step(i)^2 20*step(i)^3];
    b2(i-1,1) = 0;
end
A1 = A1/max(abs(A1(:)));A1 = [A1 zeros(size(A1,1),length(x0)-5)];
A2 = A2/max(abs(A2(:)));A2 = [A2 zeros(size(A2,1),length(x0)-5)];

diff_v = diff(polyval(cHat, 0:0.01:1),2);
if abs(sum(diff_v)) < 1e-4
    sig = 0;
else
    if length(diff_v(diff_v>0))/length(diff_v(diff_v<0))>1.5
        sig = 1;
    elseif length(diff_v(diff_v<0))/length(diff_v(diff_v>0))>1.5
        sig = -1;
    elseif length(diff_v(diff_v<0))/length(diff_v)>0.3 && length(diff_v(diff_v>0))/length(diff_v)>0.3
        sig = 0;
    end
end

Aneq = [A1; sig*A2];
bneq = [b1; sig*b2];

% sig = sum(diff(polyval(cHat, 0:0.1:1),2))/abs(sum(diff(polyval(cHat, 0:0.1:1),2)));
% if abs(sum(diff(polyval(cHat, 0:0.1:1),2))) < 1e-6
%     Aneq = A1;
%     bneq = b1;
% else
%     Aneq = [A1; sig*A2];
%     bneq = [b1; sig*b2];
% end

lb = -inf*ones(1,length(x0)); 
ub = inf*ones(1,length(x0));
lb(1:5) = flip(cHat(1:5))-0.2;
ub(1:5) = flip(cHat(1:5))+0.2;
lb(6:(5+2*numPolar)) = -1.1;
ub(6:(5+2*numPolar)) = 1.1;
lb((6+2*numPolar):(5+2*numPolar+2*numPose)) = -1.1;
ub((6+2*numPolar):(5+2*numPolar+2*numPose)) = 1.1;
lb((6+2*numPolar+2*numPose):(5+2*numPolar+numPose*(numPixel+2))) = tp-0.1;%-0.2;
ub((6+2*numPolar+2*numPose):(5+2*numPolar+numPose*(numPixel+2))) = tp+0.1;%1.2;

opts = optimset('Display','iter-detailed',...
                'Algorithm','sqp',...
                'MaxIter',300000,'MaxFunEvals',100000,...
                'FinDiffRelStep', 1e-6);%'PlotFcn', @optimplotfval);%,'PlotFcn',@optimplotstepsize);
[x_hat] = fmincon(opt_func,x0,Aneq,bneq,Aeq,beq,lb,ub,non_con,opts);

%% Deal with x
cHat_refine = [flip(x_hat(1:5)); 0]';
c_phi_refine = x_hat(6:(5+numPolar));
s_phi_refine = x_hat((6+numPolar):(5+2*numPolar),1);
c_psi_refine = x_hat((6+2*numPolar):(5+2*numPolar+numPose));
s_psi_refine = x_hat((6+2*numPolar+numPose):(5+2*numPolar+2*numPose));

tp_refine = x_hat((6+2*numPolar+2*numPose):(5+2*numPolar+numPose*(numPixel+2)))';
phi_refine = mod(atan2(s_phi_refine,c_phi_refine)/2/pi*180,180)/180*pi;
psi_refine = atan2(s_psi_refine,c_psi_refine)/2;
end