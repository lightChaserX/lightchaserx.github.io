function betaHat = pt3_lsf_line(points)
A = [];
b = [];
n = 2;
for i = 1:n
    A = [A; points(i, 1), 1];
    b = [b; points(i, 2)];
    betaHat = (A' * A) \ (A' * b);
end
%% Plot results
% xx = linspace(min(A(:, 1)), max(A(:, 1)), 20);
% yy = betaHat(1)*xx + betaHat(2);
% plot(xx, yy)
% hold on
% plot(A(:,1), b(:), 'or')
% hold off
end