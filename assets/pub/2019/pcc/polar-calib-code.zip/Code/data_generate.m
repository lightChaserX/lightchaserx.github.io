function [M] = data_generate(varargin)
%% 
% no arg input, then generate gamma=1 synthtic data
if nargin <1
    error('no enough input')
elseif nargin >= 4
    phi = varargin{1};
    psi = varargin{2};
    %c_coeff = varargin{3};
    I_max = varargin{3};
    noise_level = varargin{4};
    
end

I_min = zeros(size(I_max));
tp = (I_max+I_min)/2;
ap = (I_max-I_min)/2;
numPose = length(psi);
numPolar = length(phi);
numPixel = length(tp);
I = zeros(numPose,numPixel,numPolar);

for i = 1:numPose
    for k = 1:numPixel
        for j = 1:numPolar
            I(i, k, j) = tp(k) + ap(k)*cos(2*(phi(j) - psi(i)));
        end
    end
end
M = I*255;
%M = polyval(c_coeff, I)*255;
M = M + noise_level*rand(size(M));
end