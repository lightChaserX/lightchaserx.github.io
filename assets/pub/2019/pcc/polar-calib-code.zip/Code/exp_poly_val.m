function out = exp_poly_val(varargin)
%% exp_poly_val
c1 = varargin{1};
c2 = varargin{2};
D = varargin{3};

if isempty(c2)
    out = polyval(c1, D);
elseif isempty(c1)
    n = length(c2);
    out = c2(n).*ones(size(D));
    for i = 2:n
        out = out + c2(n-i+1).*D.^(1/(i-1));
    end
else
    n = length(c2);
    out = polyval(c1, D) + c2(n).*ones(size(D));
    for i = 2:n
        out = out + c2(n-i+1).*D.^(1/(i-1));
    end
end
end
