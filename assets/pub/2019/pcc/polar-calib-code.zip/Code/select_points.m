function [center_avr, center_box_show] = select_points(height, width, im, feature_points)
%% Points reshape
re_points = zeros(height, width, 2); %h x w x
for m = 1:height
    for n = 1:width
        re_points(m, n, :) = feature_points(:, (width-n)*height+m);
    end
end

center_pixel = center_extract(width, height, re_points);

whitecenter_box_joint = [];
k_win = 30;
for i = 2:2:length(center_pixel)
    j = floor(i/2);
    plot(center_pixel(1,i), center_pixel(2, i), '+'), hold on
    if length(size(im)) == 3
        whitecenter_box(:,:,j) = rgb2gray(im((center_pixel(2,i) - k_win):(center_pixel(2,i) + k_win),...
            (center_pixel(1, i)-k_win):(center_pixel(1,i) + k_win), :));
    else
        whitecenter_box(:,:,j) = im((center_pixel(2,i) - k_win):(center_pixel(2,i) + k_win),...
            (center_pixel(1, i)-k_win):(center_pixel(1,i) + k_win), :);
    end
end
whitecenter_avr = mean2(whitecenter_box);
whitecenter_box_show = mean(whitecenter_box(:, :, :), 3);

center_box_show = [];
for i = 1:2:length(center_pixel)
    j = floor(i/2)+1;
    plot(center_pixel(1,i), center_pixel(2, i), '+'), hold on,% pause(0.5)
    if length(size(im)) == 3
        center_box(:,:,j) = rgb2gray(im((center_pixel(2,i) - k_win):(center_pixel(2,i) + k_win),...
            (center_pixel(1, i)-k_win):(center_pixel(1,i) + k_win), :));
    else
        center_box(:,:,j) = im((center_pixel(2,i) - k_win):(center_pixel(2,i) + k_win),...
            (center_pixel(1, i)-k_win):(center_pixel(1,i) + k_win), :);
    end
    center_avr(j) = mean2(center_box(:,:,j));
    center_box_show = [center_box(:,:,j) center_box_show];
end
center_avr = [whitecenter_avr center_avr];
center_avr = flip(center_avr);
center_box_show = [center_box_show whitecenter_box_show];
end