function [phi] = refineMatrixP(Mat)
m_size = size(Mat);
assert(m_size(2) == 3, 'the width of P should be 3');
phi = atan2(Mat(:,3), Mat(:,2))/2;
end