load('dorfMat')
I_noise_level = 0;
psi_noise_level = 0;
crf_noise_level = 0;
n_dorf = 5;
phi_true = (0:5:180)/180*pi;
psi_t = [-0.7277 -0.8879 -0.4533 -0.4412 -0.5514];
dorf_select =  [7    38    42    50    60    61    68    74    75    83   110   119   129   136   182   188   193   194   195   197];

for k_times = 3:36
    %for kk = 1:100
    nu = randperm(36,k_times);
    polar_index = sort(nu);
    phi_true_sel = phi_true(polar_index);
    for n_dorf = 1:20
        I_max_t = dorfM(dorf_select(n_dorf), :);
        irradiance = dorfI(dorf_select(n_dorf), :);
        [M_measured] = data_generate(phi_true, psi_t, I_max_t, I_noise_level);
        [I_measured] = data_generate(phi_true_sel, psi_t, irradiance, crf_noise_level);
        
        M_select = M_measured(:,:,polar_index);
        psi_f = psi_t + psi_noise_level*rand(size(psi_t));
        
        phi_hat_ECCV = givenOD_ECCV(M_select, psi_f, I_measured, I_max_t, phi_true_sel);
        phi_hat_ICCP = givenOD_ICCP(M_select, psi_f, I_measured, I_max_t, phi_true_sel);
        
        RMSE_phi_ICCP(k_times,n_dorf) = sqrt(mean(((phi_hat_ICCP(2:end-1)'-phi_true_sel(2:end-1)')/pi*180).^2));
        Disparity_phi_ICCP(k_times,n_dorf) = max(abs(phi_hat_ICCP(2:end-1)'-phi_true_sel(2:end-1)'))/pi*180;
        RMSE_phi_ECCV(k_times,n_dorf) = sqrt(mean(((phi_hat_ECCV(2:end-1)'-phi_true_sel(2:end-1)')/pi*180).^2));
        Disparity_phi_ECCV(k_times,n_dorf) = max(abs(phi_hat_ECCV(2:end-1)'-phi_true_sel(2:end-1)'))/pi*180;
        sprintf('%g-%g RMSE and Disparity of polar angle is %0.5g and %0.5g\n', k_times, n_dorf, RMSE_phi_ECCV(k_times, n_dorf), Disparity_phi_ECCV(k_times, n_dorf))
        sprintf('RMSE and Disparity of polar angle is %0.5g and %0.5g\n', RMSE_phi_ICCP(k_times, n_dorf), Disparity_phi_ICCP(k_times, n_dorf))
        %end
    end
    save('syntheticCompareReduceAngleNoNoise', 'RMSE_phi_ECCV', 'RMSE_phi_ICCP', 'Disparity_phi_ECCV', 'Disparity_phi_ICCP')
end
