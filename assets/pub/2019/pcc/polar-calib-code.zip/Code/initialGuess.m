phi0 = 0;
D_matrix = ones(numPolarAngle, numPixel);
phi = zeros(1,37);

center_I = zeros(1, numPolarAngle);
psi_vec = zeros(1, numPose);
for c = 1:numPose
    for t = 1:numPixel
        for k = 1:numPolarAngle
            center_I(k) = M_measured(c, t, k);
        end
        D_matrix(:, t) = 2*(center_I - min(center_I(:)))./max(center_I - min(center_I(:)));
        figure(100), plot(phi,...
                   (center_I - min(center_I(:)))...
                   ./max(center_I - min(center_I(:))),...
                   '.'), hold on        
    end    
    O_matrix = [ones(1,numPixel); ones(1,numPixel)*cos(2*psi_vec(c)); ones(1,numPixel)*sin(2*psi_vec(c))];
     
    P_matrix = (D_matrix' * D_matrix) \ (D_matrix' * O_matrix);
    
    [psi_hat, ap, tp] = refineMatrixO(O_matrix);
    psi_vec(c) = mean(psi_hat(2:end));
    figure(100), plot(phi, 1/2+1/2*cos(2*(phi - psi_vec(c))), 'LineWidth', 1.5), hold on
end