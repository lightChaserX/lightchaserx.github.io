function my_style = export_set
%export setting
my_style = hgexport('factorystyle');
my_style.Format = 'jpeg';
my_style.Width = 8;
my_style.Height= 8;
my_style.Units = 'centimeters';
my_style.Color = 'rgb';
my_style.Background = 'w';
my_style.FixedFontSize = 11;
my_style.FontSizeMin = 8
my_style.FixedLineWidth = 1
my_style.LineWidthMin = 1
my_style.FontName = 'Arial'
my_style.Resolution = 600
my_style.Bounds = 'tight'

end