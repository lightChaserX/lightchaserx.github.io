
vec_10 = [1 0 0]';
vec_20 = [0 1 0]';
vec_30 = [0 0 1]';

% vec_10 = [0.8034 0 0.5954]';
% vec_20 = [0.1766 -0.9550 -0.2382]';
% vec_30 = [0.5686 0.2965 -0.7673]';

[r_r,p_p,y_y]=decompRotationMatrix(Rc_1);

vec_11 = rotx(r_r/pi*180)*vec_10;
vec_21 = rotx(r_r/pi*180)*vec_20;
vec_31 = rotx(r_r/pi*180)*vec_30;

vec_12 = roty(p_p/pi*180)*vec_11;
vec_22 = roty(p_p/pi*180)*vec_21;
vec_32 = roty(p_p/pi*180)*vec_31;

vec_13 = rotz(y_y/pi*180)*vec_12;
vec_23 = rotz(y_y/pi*180)*vec_22;
vec_33 = rotz(y_y/pi*180)*vec_32;

vec_14 = Rc_1*vec_10;
vec_24 = Rc_1*vec_20;
vec_34 = Rc_1*vec_30;

figure, 
    quiver3(0,0,0,vec_10(1),vec_10(2),vec_10(3),'b','LineWidth',1.5)
    hold on
    quiver3(0,0,0,vec_20(1),vec_20(2),vec_20(3),'b','LineWidth',1.5)
    quiver3(0,0,0,vec_30(1),vec_30(2),vec_30(3),'b','LineWidth',1.5)
    pause
    
    quiver3(0,0,0,vec_11(1),vec_11(2),vec_11(3),'g','LineWidth',1.5)
    hold on
    quiver3(0,0,0,vec_21(1),vec_21(2),vec_21(3),'g','LineWidth',1.5)
    quiver3(0,0,0,vec_31(1),vec_31(2),vec_31(3),'g','LineWidth',1.5)
    pause
    
    quiver3(0,0,0,vec_12(1),vec_12(2),vec_12(3),'r','LineWidth',1.5)
    hold on
    quiver3(0,0,0,vec_22(1),vec_22(2),vec_22(3),'r','LineWidth',1.5)
    quiver3(0,0,0,vec_32(1),vec_32(2),vec_32(3),'r','LineWidth',1.5)
    pause
    
    quiver3(0,0,0,vec_13(1),vec_13(2),vec_13(3),'y','LineWidth',1.5)
    hold on
    quiver3(0,0,0,vec_23(1),vec_23(2),vec_23(3),'y','LineWidth',1.5)
    quiver3(0,0,0,vec_33(1),vec_33(2),vec_33(3),'y','LineWidth',1.5)
    pause
    
    quiver3(0,0,0,vec_14(1),vec_14(2),vec_14(3),'k--','LineWidth',1.5)
    hold on
    quiver3(0,0,0,vec_24(1),vec_24(2),vec_24(3),'k--','LineWidth',1.5)
    quiver3(0,0,0,vec_34(1),vec_34(2),vec_34(3),'k--','LineWidth',1.5)
    