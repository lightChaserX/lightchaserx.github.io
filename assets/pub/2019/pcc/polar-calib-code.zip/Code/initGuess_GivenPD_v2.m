function psi = initGuess_GivenPD_v2(M, phi, cHat)
%% Initial guess of psi given M and P
%  M   - unnormalized measured intensity
%        size is numPose x numPixel x numPolarAngle
%  phi - the polarization angle

color_str     = 'rgbmky';
numPose       = length(M(:,1,1));
numPixel      = length(M(1,:,1));
numPolarAngle = length(M(1,1,:));
D_matrix      = ones(numPolarAngle, numPixel);
center_I      = zeros(1, numPixel);
psi           = zeros(1, numPose);

for c = 1:numPose
    for k = 1:numPolarAngle
        for t = 1:numPixel
            center_I(t) = M(c, t, k);
        end
        D_matrix(k, :) = center_I;
    end
    D_matrix = (D_matrix - min(D_matrix(:)))./max(max(D_matrix - min(D_matrix(:))));
    Ori_matrix = D_matrix;
    D_matrix = polyval(cHat, D_matrix);
%     figure(4),
%         plot(phi/pi*180, D_matrix,...
%             [color_str(rem(c-1,6)+1) '-']),
%         hold on
%         plot(phi/pi*180, Ori_matrix,...
%             [color_str(rem(c-1,6)+1) ':']),
%         title('Intensity data to estimate \phi, '':'' input, ''--'' undistort, ''-'' estimate')
%     
    D_matrix_copy = D_matrix(:,3:end);
    
    for t = 1:size(D_matrix_copy,2)
        for k = 2:numPolarAngle
            indics = (t-1)*(numPolarAngle-1) + k-1;
            tilde_D_matrix(indics, 1) = D_matrix_copy(1,t)-D_matrix_copy(k,t);
            tilde_P_matrix(indics, 1) = D_matrix_copy(k,t)*cos(2*phi(1))-D_matrix_copy(1,t)*cos(2*phi(k));
            tilde_P_matrix(indics, 2) = D_matrix_copy(k,t)*sin(2*phi(1))-D_matrix_copy(1,t)*sin(2*phi(k));
        end
    end
    
    O_matrix = (tilde_P_matrix' * tilde_P_matrix) \ tilde_P_matrix' * tilde_D_matrix;
    
    [psi_hat, ~, ~] = refineMatrixO(O_matrix);
    psi(c) = mean(psi_hat(1:end));
    
%     figure(4),
%         plot(phi/pi*180, 1/2+1/2*cos(2*(phi - psi(c))), color_str(rem(c-1,6)+1), 'LineWidth', 1.5),
%         hold on
end
end