function [normal_hat, theta, psi] = lsf_normal(xx, yy, zz)
%% Estimation the plane and return the vector pointing to origin
%  Usage: [normal_hat, theta, psi] = lsf_normal(YYx, YYy, YYz)
[Nx,Ny,Nz] = surfnorm(xx,yy,zz);
normal_hat(1) = mean2(Nx);
normal_hat(2) = mean2(Ny);
normal_hat(3) = mean2(Nz);

theta = acos(-normal_hat(3)/sqrt(sum(normal_hat.^2)));
psi = atan2(normal_hat(2),normal_hat(1));

figure(79),
quiver3(xx,yy,zz,Nx,Ny,Nz, 'r'); hold on, surf(xx,yy,zz), hold off

% m = length(xx(:,1)); n = length(xx(1,:));
% xx_bar = mean2(xx); yy_bar = mean2(yy); zz_bar = mean2(zz);
% A = zeros(2, 2); b = zeros(2, 1);
% for i = 1:m
%     for j = 1:n
%         A(1, 1) = A(1, 1) + (xx(i, j) - xx_bar)^2;
%         A(1, 2) = A(1, 2) + (xx(i, j) - xx_bar)*(yy(i, j) - yy_bar);
%         A(2, 1) = A(2, 1) + (xx(i, j) - xx_bar)*(yy(i, j) - yy_bar);
%         A(2, 2) = A(2, 2) + (yy(i, j) - yy_bar)^2;
%         b(1, 1) = b(1, 1) + (xx(i, j) - xx_bar)*(zz(i, j) - zz_bar);
%         b(2, 1) = b(2, 1) + (yy(i, j) - yy_bar)*(zz(i, j) - zz_bar);
%     end
% end
% betaHat = (A' * A) \ (A' * b);
% C = zz_bar - betaHat(1)*xx_bar - betaHat(2)*yy_bar;

%normal_hat = C/abs(C)*[betaHat(1), betaHat(2), -1]; % point to the origin point
%% Plot results
% figure(78),
%     surfnorm(xx,yy,zz),
%     hold on
% figure(79),
%     mesh(xx, yy, zz),
%     hold on
%     
%     for i = 1:m*n
%         quiver3(xx(i), yy(i), zz(i),...
%                 20*normal_hat(1), 20*normal_hat(2), 20*normal_hat(3));
%     end

% norm_c = cross([-xx(6) + xx(3), -yy(6) + yy(3), -zz(6) + zz(3)],...
%                [-xx(6) + xx(18), -yy(6) + yy(18), -zz(6) + zz(18)]);
% norm_c ./ norm_c(3)
% norm_c = cross([-xx(10) + xx(6), -yy(10) + yy(6), -zz(10) + zz(6)],...
%                [-xx(10) + xx(18), -yy(10) + yy(18), -zz(10) + zz(18)]);
% norm_c ./ norm_c(3)
end