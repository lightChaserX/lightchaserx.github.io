function cHat = lsq_poly_crf_k(varargin)
M_ori = varargin{1};
I = varargin{2};
I = I ./ max(I(:));
%base = -min(M_ori,[],2);!!!!
base = 0;
M_norm = (M_ori-base)./max(M_ori-base,[],2);
M = mean(M_norm, 1);
[M_height, M_width] = size(M);

color_str = 'rgbcm';
if nargin <= 2
    numOrder = 5;
else
    numOrder = varargin{3};
end
%% Constrainted least square
C = zeros(M_width*M_height, numOrder);
d = zeros(M_width*M_height, 1);
for i = 1:M_width
    for j = 1:numOrder
        C(((i-1)*M_height+1):i*M_height, j) = M(:, i).^j;
    end
    d(((i-1)*M_height+1):i*M_height, 1) = ones(M_height, 1) * I(i);
end

%First constraint is sum of coefficients add to 1. ie: g(1) =1
Aeq(1,1:numOrder) = 1; beq(1) = 1;

%Monotonic Constraint as Positive first derivative
step = 0:0.01:1;
for i = 2:length(step)
    %monotonous constraint
    for j = 1:numOrder
        A1(i-1,j) = -j*power(step(i),j-1);
        A2(i-1,j) = -(j-1)*j*power(step(i),j-2);
    end
    %convex constraint
    b1(i-1,1) = 0;
    b2(i-1,1) = 0;
end
A1 = A1/max(abs(A1(:)));
A2 = A2/max(abs(A2(:)));

diff_v = diff(M(1,2:end-1),2);
if abs(sum(diff_v)) < 1e-4
    sig = 0;
else
    if length(diff_v(diff_v>0))/length(diff_v(diff_v<0))>1.5
        sig = 1;
    elseif length(diff_v(diff_v<0))/length(diff_v(diff_v>0))>1.5
        sig = -1;
    elseif length(diff_v(diff_v<0))/length(diff_v)>0.3 && length(diff_v(diff_v>0))/length(diff_v)>0.3
        sig = 0;
%         if length(I(1,2:end-1)>M(1,2:end-1))/length(M(1,2:end-1))>=0.9 
%             sig = -1;
%         elseif length(I(1,2:end-1)<M(1,2:end-1))/length(M(1,2:end-1))>=0.9 
%             sig = 1;
%         else
%             sig = 0;
%         end
    end
end

%Aneq = [A1; -sig*A2];
%bneq = [b1; -sig*b2];

Aneq = [A1];
bneq = [b1];

options = optimoptions('lsqlin','Algorithm','interior-point','Display','off');
[cHat]=lsqlin(C,d,Aneq,bneq,Aeq,beq,[],[],[],options);
cHat = [flip(cHat); 0];

% %% Draw
% h_11 = figure(200);
%   set(h_11, 'Position', [100 500 450 400]);
% %   plot(M, I, 'g--', 'MarkerSize', 2, 'MarkerFaceColor', 'g', 'LineWidth', 2)
%   hold on
%   plot(linspace(0, 1, 100),...
%        polyval(cHat, linspace(0, 1, 100)),...
%        'm', 'LineWidth', 2)
%   grid on, axis([0 1 0 1])
%   hold on
% %   plot(linspace(0, 1, 100),...
% %        polyval([1 0], linspace(0, 1, 100)),...
% %        'k--', 'LineWidth', 1)
%   set(gca, 'XTick', 0:0.1:1);
%   set(gca, 'YTick', 0:0.1:1);
%   xlabel('Normalized observation');
%   ylabel('Normalized irradiance');
end