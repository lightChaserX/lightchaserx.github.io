clear, close all
if ~exist('Calib_Results.mat', 'file')
    error('No Calib data')
else
    %%load('M_measured'); load gamma = 0 real world data
    load('Calib_Results');
end

%%synthtic data
M_measured=data_generate; %% no arg input, then generate gamma=1 synthtic data
synthic_gamma = 2.3; % gamma= 2.3
%synthic_gamma = 1/2.3; 
M_measured = power(M_measured/256, 1/synthic_gamma)*256;

%%%%
numPose = length(M_measured(:,1,1));
irradiance = 255*(0:0.1:1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Inital Estimation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% CRF estimation
M_row_irr = reshape(permute(M_measured, [2 1 3]), 11, [])';
M_global_norm = (M_row_irr - min(M_row_irr(:)))/max(max(M_row_irr - min(M_row_irr(:))));
M_row_max = max(M_global_norm, [], 2);
M_row_irr(M_row_max <= 0.8, :) = []; %pixels selection
cHat = lsq_poly_crf([zeros(size(M_row_irr,1),1),M_row_irr],[0 irradiance]); %% add 0 as the firt col
%cHat = lsq_poly_crf(M_row_irr,irradiance); %% use the origin data
figure(1), plot(power(0:0.01:1, 1/synthic_gamma), 0:0.01:1, 'k--', 'LineWidth', 1) %% plot ground truth

%% Ground truth
phi0 = 0; phi_true = (0:36)*5/180*pi + phi0; polar_index = 2:1:36;
phi_true_sel = phi_true(polar_index);
M_select = M_measured(:,:,polar_index);

%%initGuess phase angle psi v2 method
psi_true = initGuess_GivenPD_v2(M_select, phi_true_sel, cHat);

%%initGuess phase angle psi v1 method
%psi_true = initGuess_GivenPD(M_measured, phi_true)

%% initGuess psi
for i=1:numPose
    eval(['[rho(' num2str(i)...
        '), pitch(' num2str(i)...
        '), yaw(' num2str(i)...
        ')] = decompRotationMatrix(Rc_' num2str(i) ');']);
end
psi_hat = yaw-2.25;
%psi_hat = psi_true+(rand(size(psi_true))-0.5)*0.1/180*pi;

%%initGuess polar angle phi v2 method
phi_hat = initGuess_GivenOD_v2(M_select, psi_hat, cHat, phi_true_sel);

%%initGuess polar angle phi v1 method
%phi_hat = initGuess_GivenOD(M_measured, psi_hat, cHat);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ICCP BA method
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Find_OP
% figure(137),
%     plot((recovered_object_angle_degrees-180), 'g')

%%fmincon BA method
%[cHat_refine,phi_refine,psi_refine,tp_refine] = BAfmincon(cHat,phi_hat,psi_hat,M_select);
[cHat_refine,phi_refine,psi_refine,tp_refine] = BAfmincon_v2(cHat,phi_hat,psi_hat,M_select);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Show results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1),
plot(0:0.01:1,...
    polyval(cHat_refine, 0:0.01:1),...
    'c--', 'LineWidth', 1.5)
    legend('Data','Estimated','GT','Refined','Location','NorthWest')
title('Inverse CRF')

figure(2),
plot((0:36)*5, (0:36)*5, 'r', 'LineWidth', 1.5)
plot(phi_true(polar_index)/pi*180, phi_refine/pi*180,...
    'o', 'Color', 'b',...
    'MarkerFaceColor', 'b',...
    'MarkerSize', 3),
title('Polar angle \phi')
legend('Estimated','GT','Refined','Location','NorthWest')

h_137 = figure(3);
set(h_137, 'Position', [100 500 450 400]);
plot((psi_true)/pi*180,'m-s','LineWidth',1.5)
hold on
plot((psi_hat)/pi*180,'g-o','LineWidth',1.5)
plot(psi_refine/pi*180,'c-^','LineWidth',1.5);
legend('Ground truth', 'Estimated', 'Refined')
grid on, axis([1 numPose -90 90])
set(gca, 'XTick', 1:numPose);
set(gca, 'YTick', -90:20:90);
title('Phase angle \psi')

RMSE = sqrt(mean((phi_refine(2:end-1)-phi_true(polar_index(2:end-1))').^2))/pi*180;
Disparity = max(abs(phi_refine(2:end-1)-phi_true(polar_index(2:end-1))'))/pi*180;
sprintf('RMSE and Disparity of polar angle is\n %0.5g and %0.5g', RMSE, Disparity)
RMSE = sqrt(mean((psi_refine-psi_true').^2))/pi*180;
Disparity = max(abs(psi_refine-psi_true'))/pi*180;
sprintf('RMSE and Disparity of phase angle is\n %0.5g and %0.5g', RMSE, Disparity)
crf_diff = polyval(cHat_refine, 0:0.01:1)-power(0:0.01:1, 1/synthic_gamma);
RMSE = sqrt(mean((crf_diff).^2));
Disparity = max(abs(crf_diff));
sprintf('RMSE and Disparity of CRF is\n %0.5g and %0.5g', RMSE, Disparity)