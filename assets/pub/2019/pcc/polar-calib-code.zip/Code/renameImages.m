dir_files = dir('*.tif');
for i = 1:length(dir_files)
    fprintf([dir_files(i).name '\n'])
    imwrite(uint8(imread(dir_files(i).name)/(2^8)), ['Image' num2str(i) '.jpg']);
end

%% Fetch from P to Rotate
% for i=1:10
%     for j = 1:5
%         ft_im_name = ['P' num2str(j) '/Image' num2str(i) '.jpg'];
%         if mkdir(['R' num2str(i)])
%             imwrite(imread(ft_im_name), ['R' num2str(i) '/Image' num2str(j) '.jpg']);
%         end
%     end
% end