function betaHat = lsf_line(re_points, index)
n = length(index);
A = [];
b = [];
for i = 1:n
    A = [A; re_points(index(1, i), index(2, i), 1), 1];
    b = [b; re_points(index(1, i), index(2, i), 2)];
    betaHat = (A' * A) \ (A' * b);
end
%% Plot results
% xx = linspace(min(A(:, 1)), max(A(:, 1)), 20);
% yy = betaHat(1)*xx + betaHat(2);
% plot(xx, yy)
% hold on
% plot(A(:,1), b(:), 'or')
% hold off
end