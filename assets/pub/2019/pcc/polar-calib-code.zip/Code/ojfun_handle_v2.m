function f = ojfun_handle_v2(c,c_phi,s_phi,c_psi,s_psi,tp_full, D)
f = 0;
numPolar = size(D,1);
numPose  = size(D,2);
numPixel = size(D,3);

for j = 1:numPixel
t = tp_full((1+(j-1)*numPose):j*numPose);
M = reshape(D(:,:,j),numPolar,[]);
f = f + norm(2.*poly_mix([c; 0], M) -...
            [ones(length(c_phi),1),c_phi,s_phi]...
            *([t.*ones(1,length(t)); (t).*ones(2,length(t))]...
            .*[ones(1,length(c_psi));c_psi;s_psi]), 2);
end
f = f + .1*norm(c,2);
end